## Footer

Based on [`Current`](https://github.com/C5T/Current/).
