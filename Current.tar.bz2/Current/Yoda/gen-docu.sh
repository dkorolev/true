#!/bin/bash
../scripts/gen-docu.sh >DOCU.md
