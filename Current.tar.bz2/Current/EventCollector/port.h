// Surprise: Windows doesn't support symlinks! Doin' it the good ol' way.
#include "../port.h"
