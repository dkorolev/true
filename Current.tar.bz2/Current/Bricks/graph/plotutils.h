#ifndef CURRENT_TEST_COMPILATION
#error "Bricks `plotutils` binding has been deprecated. Please use the `gnuplot` one instead."
#endif  // CURRENT_TEST_COMPILATION
