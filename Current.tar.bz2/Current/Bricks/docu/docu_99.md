## Extras

[`Bricks`](https://github.com/C5T/Current/) contains several other useful bits, including cross-platform file system wrapper, string manipulation functions, in-memory message queue and system clock utilities.
