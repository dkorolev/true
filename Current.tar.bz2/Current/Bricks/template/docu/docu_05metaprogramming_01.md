## Functional Template Library

Bricks makes extensive use of C++11 variadic templates. A few generic methods are exposed as `bricks::metaprogramming`.
