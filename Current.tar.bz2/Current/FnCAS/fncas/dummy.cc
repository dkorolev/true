// https://github.com/dkorolev/fncas

#include <iostream>

#include "fncas.h"

int main() { std::cout << "#include \"fncas.h\" compiled OK." << std::endl; }
