// This file added by dkorolev.

#ifndef THIRDPARTY_GTEST_H
#define THIRDPARTY_GTEST_H

#include "src/gtest-all.cc"

#endif  // THIRDPARTY_GTEST_H
