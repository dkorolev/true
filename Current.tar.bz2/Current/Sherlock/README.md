# Sherlock

[`Sherlock`](https://github.com/C5T/Current/) is a structured, append-only, immutable data persistence layer with publish-subscribe.

![](https://raw.githubusercontent.com/C5T/Current/master/Sherlock/static/sherlock.jpg)

<sub>Image credit: The graffiti of [Sherlock Holmes](http://en.wikipedia.org/wiki/Sherlock_Holmes). Found via Bing image search.</sub>
