# StreamSystem (SS)

Defines the unified interface for `Current` stream processing.

`TODO(dkorolev)`: Order keys, defaults, their extraction, and monotonicity guarantees. Later.

Defines:

* Current **Publisher**
* Current **Listener**

Descriptions TBD.
