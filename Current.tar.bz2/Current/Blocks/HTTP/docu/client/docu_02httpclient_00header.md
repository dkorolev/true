## REST API Toolkit

The [`#include "Blocks/HTTP/api.h"`](https://github.com/C5T/Current/blob/master/Blocks/HTTP/api.h) header enables to run the code snippets below.

### HTTP Client

